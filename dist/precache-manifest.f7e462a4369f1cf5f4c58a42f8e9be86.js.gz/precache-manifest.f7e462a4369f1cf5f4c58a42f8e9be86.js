self.__precacheManifest = [
  {
    "revision": "11f56b90ae8f20eb6ff1",
    "url": "/css/app.c456245b.css"
  },
  {
    "revision": "11f56b90ae8f20eb6ff1",
    "url": "/js/app.cd8a4fc0.js"
  },
  {
    "revision": "6de8590a1169a813b9d7",
    "url": "/js/chunk-0635b894.393f82b4.js"
  },
  {
    "revision": "346673aef5e0ffa44e2e",
    "url": "/js/chunk-0c51c218.24bdc71a.js"
  },
  {
    "revision": "b91dc68885597566ed64",
    "url": "/css/chunk-0e87b34a.0ec54d11.css"
  },
  {
    "revision": "b91dc68885597566ed64",
    "url": "/js/chunk-0e87b34a.abd650d4.js"
  },
  {
    "revision": "d0f1a1afcbfb5a0604c1",
    "url": "/css/chunk-187f2124.14f5a390.css"
  },
  {
    "revision": "d0f1a1afcbfb5a0604c1",
    "url": "/js/chunk-187f2124.505ff3b0.js"
  },
  {
    "revision": "475cc5030865f21b3b38",
    "url": "/js/chunk-233fcbac.3c0e91cf.js"
  },
  {
    "revision": "4c1f5b292f408f1e64c0",
    "url": "/css/chunk-27af5152.dc57f770.css"
  },
  {
    "revision": "4c1f5b292f408f1e64c0",
    "url": "/js/chunk-27af5152.00abe0fc.js"
  },
  {
    "revision": "638e81d7d15edc8afbf0",
    "url": "/js/chunk-2d0a4296.30001d38.js"
  },
  {
    "revision": "19f303d1d1b59b2789ab",
    "url": "/js/chunk-2d0aa7aa.e5c61211.js"
  },
  {
    "revision": "fea91e597bd35af05d39",
    "url": "/js/chunk-2d0af63f.b70b0550.js"
  },
  {
    "revision": "b531a5503efaeb7fb936",
    "url": "/js/chunk-2d0b3430.23bb4f26.js"
  },
  {
    "revision": "173487d89503056901e2",
    "url": "/js/chunk-2d0b7259.2cd791ef.js"
  },
  {
    "revision": "91ef1373ea1df65c4fb6",
    "url": "/js/chunk-2d0b99e6.28d8de0a.js"
  },
  {
    "revision": "1a817d308301bf4cfcf5",
    "url": "/js/chunk-2d0ba690.4d9df058.js"
  },
  {
    "revision": "9e4899826c9e13d9e3db",
    "url": "/js/chunk-2d0bd5a9.8d247330.js"
  },
  {
    "revision": "d736b0c1724b3bee98ca",
    "url": "/js/chunk-2d0c1216.efe28d38.js"
  },
  {
    "revision": "9abf4b9f0228c8e8964d",
    "url": "/js/chunk-2d0c18ec.4b9150e3.js"
  },
  {
    "revision": "11d498901e6082f9c618",
    "url": "/js/chunk-2d0c1d75.104df796.js"
  },
  {
    "revision": "5c28520d5f8fabee3da2",
    "url": "/js/chunk-2d0c517c.542175cd.js"
  },
  {
    "revision": "24f10b230f61ed39dc3a",
    "url": "/js/chunk-2d0c9b38.65b284f6.js"
  },
  {
    "revision": "e854d92cc1f1fa052028",
    "url": "/js/chunk-2d0cef72.d8f730fa.js"
  },
  {
    "revision": "a948686a4ed70f725789",
    "url": "/js/chunk-2d0d0042.8e1e0626.js"
  },
  {
    "revision": "3d31f0a3275c9d5ccc0c",
    "url": "/js/chunk-2d0d01cb.c2552002.js"
  },
  {
    "revision": "208b5ee721d747bc401f",
    "url": "/js/chunk-2d0d05d3.186268a2.js"
  },
  {
    "revision": "e21d4c63f17fe47d1913",
    "url": "/js/chunk-2d0d3dd9.36c1ff24.js"
  },
  {
    "revision": "39f83038c5693feced53",
    "url": "/js/chunk-2d0d43ea.1e1e1da2.js"
  },
  {
    "revision": "306e72288a256bd051d1",
    "url": "/js/chunk-2d0d643d.8c65bd22.js"
  },
  {
    "revision": "ff40b00b0c1468873cfc",
    "url": "/js/chunk-2d0d76f5.bec42df5.js"
  },
  {
    "revision": "68eddf9e7f12d938ed04",
    "url": "/js/chunk-2d0dd0e9.e56a393a.js"
  },
  {
    "revision": "b102a21fdf52ce63031d",
    "url": "/js/chunk-2d0dd7b6.927f9ae8.js"
  },
  {
    "revision": "ef8f319ad1616ee50904",
    "url": "/js/chunk-2d0dee78.c50c0a5f.js"
  },
  {
    "revision": "ad80b8d7f2992d930cc4",
    "url": "/js/chunk-2d0df0c5.87845af5.js"
  },
  {
    "revision": "7a7b8c5b3af045d40ad6",
    "url": "/js/chunk-2d0e5983.7ebedc7f.js"
  },
  {
    "revision": "fd491ed80ab4275c0fd6",
    "url": "/js/chunk-2d0e5bcf.8ab5188c.js"
  },
  {
    "revision": "d4eaee67a8b8251ed1f3",
    "url": "/js/chunk-2d0e5f64.8d86eb87.js"
  },
  {
    "revision": "f254e7235b595b74598c",
    "url": "/js/chunk-2d0e91b6.c888a301.js"
  },
  {
    "revision": "660fe4e9c2599e28a1c2",
    "url": "/js/chunk-2d0f11e1.f27afc01.js"
  },
  {
    "revision": "12c05b774d4367b88e3c",
    "url": "/js/chunk-2d20efc9.536de7ad.js"
  },
  {
    "revision": "ddc0b260bbbdf66ff881",
    "url": "/js/chunk-2d21765f.64a22a7b.js"
  },
  {
    "revision": "390116211d944993ec74",
    "url": "/js/chunk-2d21df49.9db399e7.js"
  },
  {
    "revision": "453f5446af182eb7dbea",
    "url": "/js/chunk-2d21e72d.49670cbf.js"
  },
  {
    "revision": "a250af854cdc3c22af7c",
    "url": "/js/chunk-2d21e73b.b5f38dcc.js"
  },
  {
    "revision": "91c45f6fd3a501e6e7ba",
    "url": "/js/chunk-2d21eaec.e77cb6a8.js"
  },
  {
    "revision": "3731df10387e3d35f451",
    "url": "/js/chunk-2d221836.ba5ad897.js"
  },
  {
    "revision": "d335ce0e781b5f3ed37d",
    "url": "/js/chunk-2d224c47.b67ef926.js"
  },
  {
    "revision": "13eb45d352fcc33bc861",
    "url": "/js/chunk-2d226365.9a08f889.js"
  },
  {
    "revision": "9111800c5efac2f332af",
    "url": "/js/chunk-2d2288f6.3f5a26ce.js"
  },
  {
    "revision": "ba84c5704291c4e54502",
    "url": "/js/chunk-2d22998c.820c7a4f.js"
  },
  {
    "revision": "017fffcd3898a0bc3895",
    "url": "/js/chunk-2d22c342.ecce7168.js"
  },
  {
    "revision": "eb11ae1ad48841a1b856",
    "url": "/js/chunk-2d22c8c0.30d2a680.js"
  },
  {
    "revision": "4ed943714305bb54b2ba",
    "url": "/js/chunk-2d22d09e.b6992965.js"
  },
  {
    "revision": "a4e1c57689c8ca0f6139",
    "url": "/js/chunk-2d22dd18.9a2ac2df.js"
  },
  {
    "revision": "2154880ebf3b2b130bd4",
    "url": "/js/chunk-2d22fdaf.0a7cb793.js"
  },
  {
    "revision": "db4ea4891dd1cefaa0f6",
    "url": "/js/chunk-2d2311e3.9ab6a4d9.js"
  },
  {
    "revision": "19734583024bdbf65716",
    "url": "/js/chunk-3b1a2dd3.41190d4d.js"
  },
  {
    "revision": "603e22087c1f5a411671",
    "url": "/js/chunk-3db82698.69e11d6c.js"
  },
  {
    "revision": "e35071a06eb445781251",
    "url": "/js/chunk-3df67a74.8443c77c.js"
  },
  {
    "revision": "b269f123eeb517147aad",
    "url": "/js/chunk-4472d5c6.c19e5deb.js"
  },
  {
    "revision": "145d0581ff7c5629a4f7",
    "url": "/js/chunk-47d6abce.10290714.js"
  },
  {
    "revision": "1b8eeb5325ee8465516d",
    "url": "/js/chunk-5c7378b1.8abba2ff.js"
  },
  {
    "revision": "fdc7e43d6264c8beb158",
    "url": "/js/chunk-5e7635af.ee3fc63a.js"
  },
  {
    "revision": "5cf8a6d7d3c666ec2813",
    "url": "/css/chunk-61100a86.54376608.css"
  },
  {
    "revision": "5cf8a6d7d3c666ec2813",
    "url": "/js/chunk-61100a86.792c87d6.js"
  },
  {
    "revision": "e62b29ea29b001c57e40",
    "url": "/js/chunk-65d34140.76d90f11.js"
  },
  {
    "revision": "db738b3e82685cb73709",
    "url": "/css/chunk-6734cd1a.0e433876.css"
  },
  {
    "revision": "db738b3e82685cb73709",
    "url": "/js/chunk-6734cd1a.99163e00.js"
  },
  {
    "revision": "eb1d348237acc97152c1",
    "url": "/js/chunk-70242282.be91c379.js"
  },
  {
    "revision": "99b88141efbf80680f2b",
    "url": "/css/chunk-74544e1f.d6b89405.css"
  },
  {
    "revision": "99b88141efbf80680f2b",
    "url": "/js/chunk-74544e1f.fcc3cc08.js"
  },
  {
    "revision": "0f0f3c05c8735bb1c61b",
    "url": "/js/chunk-74597ca9.f872454b.js"
  },
  {
    "revision": "4f355d66397f9c6531c8",
    "url": "/css/chunk-746799a8.c1291e20.css"
  },
  {
    "revision": "4f355d66397f9c6531c8",
    "url": "/js/chunk-746799a8.c56be9c5.js"
  },
  {
    "revision": "bb059199ca8ba860ad6e",
    "url": "/css/chunk-74693142.590e2f8c.css"
  },
  {
    "revision": "bb059199ca8ba860ad6e",
    "url": "/js/chunk-74693142.54ff49c1.js"
  },
  {
    "revision": "e278a8112e9538c9fb15",
    "url": "/css/chunk-74697fd9.86e39baa.css"
  },
  {
    "revision": "e278a8112e9538c9fb15",
    "url": "/js/chunk-74697fd9.1d158c2f.js"
  },
  {
    "revision": "ae5fe240910870251fac",
    "url": "/css/chunk-746f9064.cebd1ae4.css"
  },
  {
    "revision": "ae5fe240910870251fac",
    "url": "/js/chunk-746f9064.9032b459.js"
  },
  {
    "revision": "7dd763098ebd2b067f12",
    "url": "/css/chunk-74704285.15e03f7b.css"
  },
  {
    "revision": "7dd763098ebd2b067f12",
    "url": "/js/chunk-74704285.04f5c622.js"
  },
  {
    "revision": "d46087951539727a384f",
    "url": "/css/chunk-7475f6ab.c472db02.css"
  },
  {
    "revision": "d46087951539727a384f",
    "url": "/js/chunk-7475f6ab.f3d98962.js"
  },
  {
    "revision": "f816557932629be4ab2c",
    "url": "/css/chunk-7476dfa7.705436ed.css"
  },
  {
    "revision": "f816557932629be4ab2c",
    "url": "/js/chunk-7476dfa7.c7e76b5d.js"
  },
  {
    "revision": "0f689103eaeaee09552d",
    "url": "/css/chunk-7477fe0a.76965173.css"
  },
  {
    "revision": "0f689103eaeaee09552d",
    "url": "/js/chunk-7477fe0a.d567e0ab.js"
  },
  {
    "revision": "fb83ce8b5cac3c4b023b",
    "url": "/css/chunk-747d763f.b334a195.css"
  },
  {
    "revision": "fb83ce8b5cac3c4b023b",
    "url": "/js/chunk-747d763f.a6cbe398.js"
  },
  {
    "revision": "a97f585145f4e648a6d7",
    "url": "/css/chunk-7482abbb.c8d9ae0f.css"
  },
  {
    "revision": "a97f585145f4e648a6d7",
    "url": "/js/chunk-7482abbb.0eb7d5f1.js"
  },
  {
    "revision": "8066ffef6c15865df359",
    "url": "/css/chunk-7484083d.f65e4a87.css"
  },
  {
    "revision": "8066ffef6c15865df359",
    "url": "/js/chunk-7484083d.cf06ce9f.js"
  },
  {
    "revision": "56c3c423bd12797be8ef",
    "url": "/css/chunk-74847767.1bb9eba2.css"
  },
  {
    "revision": "56c3c423bd12797be8ef",
    "url": "/js/chunk-74847767.ca32f2a8.js"
  },
  {
    "revision": "14f7c4cc69f07b5bcc90",
    "url": "/css/chunk-748a351e.0a9f5724.css"
  },
  {
    "revision": "14f7c4cc69f07b5bcc90",
    "url": "/js/chunk-748a351e.e04d7aa9.js"
  },
  {
    "revision": "4a89b7d2d97b4268ec72",
    "url": "/css/chunk-74b10368.4d5b9433.css"
  },
  {
    "revision": "4a89b7d2d97b4268ec72",
    "url": "/js/chunk-74b10368.db93a90c.js"
  },
  {
    "revision": "727e7b15ac70ec492524",
    "url": "/js/chunk-74b64517.60dc19bb.js"
  },
  {
    "revision": "f52247011d5b59c92273",
    "url": "/css/chunk-74b6f911.15a377f8.css"
  },
  {
    "revision": "f52247011d5b59c92273",
    "url": "/js/chunk-74b6f911.c4b2a234.js"
  },
  {
    "revision": "2edd98d17df772101962",
    "url": "/css/chunk-74bc2e8d.d56b81c4.css"
  },
  {
    "revision": "2edd98d17df772101962",
    "url": "/js/chunk-74bc2e8d.b13b382b.js"
  },
  {
    "revision": "44c3d664a5b167fc0d04",
    "url": "/css/chunk-74bcdefc.8b75978f.css"
  },
  {
    "revision": "44c3d664a5b167fc0d04",
    "url": "/js/chunk-74bcdefc.fbbba76a.js"
  },
  {
    "revision": "b154f6a780b20a87bb29",
    "url": "/css/chunk-74d2b031.7c7a9349.css"
  },
  {
    "revision": "b154f6a780b20a87bb29",
    "url": "/js/chunk-74d2b031.34fe3e09.js"
  },
  {
    "revision": "0cadfe6aaa695a43d333",
    "url": "/css/chunk-76f25df5.43f8b560.css"
  },
  {
    "revision": "0cadfe6aaa695a43d333",
    "url": "/js/chunk-76f25df5.0b4bf548.js"
  },
  {
    "revision": "feb13395b93317a005fc",
    "url": "/css/chunk-76fe9cf4.01201d47.css"
  },
  {
    "revision": "feb13395b93317a005fc",
    "url": "/js/chunk-76fe9cf4.7143307a.js"
  },
  {
    "revision": "d02f8a103591488894be",
    "url": "/css/chunk-770e1ae5.69d77d8f.css"
  },
  {
    "revision": "d02f8a103591488894be",
    "url": "/js/chunk-770e1ae5.66cb50b1.js"
  },
  {
    "revision": "fb723fa7e36e1a794e6d",
    "url": "/css/chunk-7718b8f7.6679f161.css"
  },
  {
    "revision": "fb723fa7e36e1a794e6d",
    "url": "/js/chunk-7718b8f7.af82220b.js"
  },
  {
    "revision": "91b0a4f72ccb3efa14a0",
    "url": "/css/chunk-771afaf2.c114e4f6.css"
  },
  {
    "revision": "91b0a4f72ccb3efa14a0",
    "url": "/js/chunk-771afaf2.125d2d18.js"
  },
  {
    "revision": "3f152976740abb77138e",
    "url": "/css/chunk-772256ae.75cdff95.css"
  },
  {
    "revision": "3f152976740abb77138e",
    "url": "/js/chunk-772256ae.3d4b7075.js"
  },
  {
    "revision": "a97ea7de958f6924f3c7",
    "url": "/css/chunk-7722bfab.29344134.css"
  },
  {
    "revision": "a97ea7de958f6924f3c7",
    "url": "/js/chunk-7722bfab.ebfe7a2e.js"
  },
  {
    "revision": "dde34286ddff9f8f092b",
    "url": "/css/chunk-77271350.21d807f4.css"
  },
  {
    "revision": "dde34286ddff9f8f092b",
    "url": "/js/chunk-77271350.5cc5216f.js"
  },
  {
    "revision": "92706acdf4e7965ccbaa",
    "url": "/css/chunk-772efa8c.2df2f851.css"
  },
  {
    "revision": "92706acdf4e7965ccbaa",
    "url": "/js/chunk-772efa8c.2f89ab3a.js"
  },
  {
    "revision": "7fd08a678d99760c863c",
    "url": "/js/chunk-7c657845.d4e83a7c.js"
  },
  {
    "revision": "4d7daa58184849c44891",
    "url": "/js/chunk-8e96c7b4.5f31053a.js"
  },
  {
    "revision": "7284a56c4e92dbce1ff7",
    "url": "/js/chunk-8f357284.2f9f68df.js"
  },
  {
    "revision": "0cd9d2f3ba6a615c5d5f",
    "url": "/js/chunk-c70479e6.0c614cc5.js"
  },
  {
    "revision": "425174bb6b00280f9700",
    "url": "/js/chunk-e56fc180.975cf220.js"
  },
  {
    "revision": "536d244589dc839efc9c",
    "url": "/css/chunk-vendors.fdb823ea.css"
  },
  {
    "revision": "536d244589dc839efc9c",
    "url": "/js/chunk-vendors.d1b4ef64.js"
  },
  {
    "revision": "95dc3f1e2be8afce3f0c",
    "url": "/js/error.af2def90.js"
  },
  {
    "revision": "6c90e9549bbce923ba36",
    "url": "/js/follow.adceaba2.js"
  },
  {
    "revision": "ac7d2786462dd8abc607",
    "url": "/js/location.c1eb309d.js"
  },
  {
    "revision": "143494ba134b7b5b5441",
    "url": "/js/maintenance.2b198d17.js"
  },
  {
    "revision": "1c03db84a13e6d0aea4a",
    "url": "/js/news.c248580b.js"
  },
  {
    "revision": "c3baca85ac59ef842ed1",
    "url": "/js/rooms.9e5c9b7c.js"
  },
  {
    "revision": "fad5e078adcdc319bca6c456eef8692a",
    "url": "/img/bg_placeholder.fad5e078.jpg"
  },
  {
    "revision": "68be39881ef35f9ca8493c2d3d82bb21",
    "url": "/img/icon_star.68be3988.svg"
  },
  {
    "revision": "0ce8075c6af52188e3fa315bf513dcba",
    "url": "/img/bg_location.0ce8075c.jpg"
  },
  {
    "revision": "5b261d0ef7d54c0898007b68beee6e5e",
    "url": "/img/button_header_active.5b261d0e.png"
  },
  {
    "revision": "bea3d8f400c48cb70a9c6fde2f8c82bc",
    "url": "/img/button_rooms_active.bea3d8f4.svg"
  },
  {
    "revision": "cc9a7323e3599f53ff59f5200cae47c6",
    "url": "/img/placeholder.cc9a7323.jpg"
  },
  {
    "revision": "bcd9739c134a8131f8854afa3cf73dff",
    "url": "/img/button_rooms_active_arrow.bcd9739c.svg"
  },
  {
    "revision": "411860f37055806ff3d826df07bf8581",
    "url": "/img/icon_position_active.411860f3.svg"
  },
  {
    "revision": "c497edc5fdbc8c931c62a41d2b52a2c3",
    "url": "/img/icon_ship_active.c497edc5.svg"
  },
  {
    "revision": "1d2cdeb6e8eade0838f75dc943295043",
    "url": "/img/icon_airplane_active.1d2cdeb6.svg"
  },
  {
    "revision": "7fd7f09ce3e94213071ac4bad5bcded9",
    "url": "/img/button_order_active.7fd7f09c.svg"
  },
  {
    "revision": "0f8d51f26902e7a0e081f4526564ed8f",
    "url": "/img/map_arrow.0f8d51f2.svg"
  },
  {
    "revision": "5582497245d2b09da0d629a03d2fbd6b",
    "url": "/img/text-order.55824972.png"
  },
  {
    "revision": "7c12bc30c4314552764c6a6e59251b35",
    "url": "/img/logo_horizon.7c12bc30.svg"
  },
  {
    "revision": "1a57ca49ecd7b8525f6e34a53997c1ae",
    "url": "/img/cloud_center.1a57ca49.svg"
  },
  {
    "revision": "9ecd4117411947f4692af455ec2f6358",
    "url": "/img/icon_wechat.9ecd4117.svg"
  },
  {
    "revision": "94c9c6ca90f59c24455c22a426f31675",
    "url": "/img/icon_ship.94c9c6ca.svg"
  },
  {
    "revision": "2f9012a08131ed40a1e25849752f75a9",
    "url": "/img/icon_header.2f9012a0.svg"
  },
  {
    "revision": "5b9d462610122986d007270cf51702cc",
    "url": "/img/icon_airplane.5b9d4626.svg"
  },
  {
    "revision": "c9e81a3156d5be091a77a011921ee46d",
    "url": "/img/icon_instagram.c9e81a31.svg"
  },
  {
    "revision": "7de27202d8ac2f321133ba78534d4df0",
    "url": "/img/icon_white_wechat.7de27202.svg"
  },
  {
    "revision": "541e9e83c9e32f084d7f336c7de46ab8",
    "url": "/img/cloud_right.541e9e83.svg"
  },
  {
    "revision": "ec821ecaa7872d34aab24409d2371efd",
    "url": "/img/icon_airplane.ec821eca.svg"
  },
  {
    "revision": "f659e93e084d949fd30035cff184d6da",
    "url": "/img/bg_footer.f659e93e.png"
  },
  {
    "revision": "df632b4395dfe25a3b9a09b5b9e788f3",
    "url": "/img/icon_facebook.df632b43.svg"
  },
  {
    "revision": "459118748df2a5fcd7f684546cc8591b",
    "url": "/fonts/materialdesignicons-webfont.45911874.woff2"
  },
  {
    "revision": "4b882ad484d11b49f4a69212ad8e8901",
    "url": "/fonts/materialdesignicons-webfont.4b882ad4.woff"
  },
  {
    "revision": "abb4e7492eaa88c31ff103064f2b2cba",
    "url": "/fonts/materialdesignicons-webfont.abb4e749.eot"
  },
  {
    "revision": "d15c1216957060fac577af6151fb8cfe",
    "url": "/fonts/materialdesignicons-webfont.d15c1216.ttf"
  },
  {
    "revision": "ae4dbede9d81a20c842b30332ab4e5b6",
    "url": "/img/materialdesignicons-webfont.ae4dbede.svg"
  },
  {
    "revision": "ae21c1cfa3f56d9b532fdabf1841964f",
    "url": "/img/qrcode-wechat.ae21c1cf.jpg"
  },
  {
    "revision": "8813054c652e01fc7a0640eba645656e",
    "url": "/img/icon-address.8813054c.svg"
  },
  {
    "revision": "61db5d0f44b4f9acfbe7e90cbf8e6c38",
    "url": "/img/cloud03.61db5d0f.png"
  },
  {
    "revision": "22c89b842f53c45520536192f7e2cd53",
    "url": "/img/icon_ship.22c89b84.svg"
  },
  {
    "revision": "90bf12eec51d4f67af807b07f464dd9b",
    "url": "/img/footer_ship.90bf12ee.svg"
  },
  {
    "revision": "289cca12abb662a0ece838906944c4a8",
    "url": "/img/button_bg_order.289cca12.png"
  },
  {
    "revision": "5fec65adc015c0f0559b20b85921ce68",
    "url": "/img/cloud01.5fec65ad.png"
  },
  {
    "revision": "e95712e2f1bef031055432ced9c7a115",
    "url": "/img/map_airplane.e95712e2.png"
  },
  {
    "revision": "a387d9f5de3fc8c0090c665de499e79b",
    "url": "/img/icon_phone.a387d9f5.svg"
  },
  {
    "revision": "2372bd976a5298f76a3a0dd24a4abdf7",
    "url": "/img/bg_order.2372bd97.png"
  },
  {
    "revision": "8d94fb10d5d21d139de3105904bfc0f5",
    "url": "/img/icon_line.8d94fb10.svg"
  },
  {
    "revision": "3c6f5631cf1b7e5593ff542f3e0d72c5",
    "url": "/img/footer_map.3c6f5631.svg"
  },
  {
    "revision": "20afa8e4945a2210baee2c997c2a87b3",
    "url": "/img/icon_position.20afa8e4.svg"
  },
  {
    "revision": "6f171a9b3314fe4731061d9bff383abe",
    "url": "/img/titleBoatStar.6f171a9b.svg"
  },
  {
    "revision": "d3b47375afd904983d9be8d6e239a949",
    "url": "/fonts/Roboto-Thin.d3b47375.woff"
  },
  {
    "revision": "5b4a33e176ff736a74f0ca2dd9e6b396",
    "url": "/fonts/Roboto-ThinItalic.5b4a33e1.woff2"
  },
  {
    "revision": "8a96edbbcd9a6991d79371aed0b0288e",
    "url": "/fonts/Roboto-ThinItalic.8a96edbb.woff"
  },
  {
    "revision": "ad538a69b0e8615ed0419c4529344ffc",
    "url": "/fonts/Roboto-Thin.ad538a69.woff2"
  },
  {
    "revision": "d26871e8149b5759f814fd3c7a4f784b",
    "url": "/fonts/Roboto-Light.d26871e8.woff2"
  },
  {
    "revision": "c73eb1ceba3321a80a0aff13ad373cb4",
    "url": "/fonts/Roboto-Light.c73eb1ce.woff"
  },
  {
    "revision": "e8eaae902c3a4dacb9a5062667e10576",
    "url": "/fonts/Roboto-LightItalic.e8eaae90.woff2"
  },
  {
    "revision": "13efe6cbc10b97144a28310ebdeda594",
    "url": "/fonts/Roboto-LightItalic.13efe6cb.woff"
  },
  {
    "revision": "73f0a88bbca1bec19fb1303c689d04c6",
    "url": "/fonts/Roboto-Regular.73f0a88b.woff2"
  },
  {
    "revision": "f5902d5ef961717ed263902fc429e6ae",
    "url": "/fonts/Roboto-RegularItalic.f5902d5e.woff"
  },
  {
    "revision": "4357beb823a5f8d65c260f045d9e019a",
    "url": "/fonts/Roboto-RegularItalic.4357beb8.woff2"
  },
  {
    "revision": "35b07eb2f8711ae08d1f58c043880930",
    "url": "/fonts/Roboto-Regular.35b07eb2.woff"
  },
  {
    "revision": "90d1676003d9c28c04994c18bfd8b558",
    "url": "/fonts/Roboto-Medium.90d16760.woff2"
  },
  {
    "revision": "83e114c316fcc3f23f524ec3e1c65984",
    "url": "/fonts/Roboto-MediumItalic.83e114c3.woff"
  },
  {
    "revision": "50d75e48e0a3ddab1dd15d6bfb9d3700",
    "url": "/fonts/Roboto-Bold.50d75e48.woff"
  },
  {
    "revision": "13ec0eb5bdb821ff4930237d7c9f943f",
    "url": "/fonts/Roboto-MediumItalic.13ec0eb5.woff2"
  },
  {
    "revision": "1d6594826615607f6dc860bb49258acb",
    "url": "/fonts/Roboto-Medium.1d659482.woff"
  },
  {
    "revision": "b52fac2bb93c5858f3f2675e4b52e1de",
    "url": "/fonts/Roboto-Bold.b52fac2b.woff2"
  },
  {
    "revision": "94008e69aaf05da75c0bbf8f8bb0db41",
    "url": "/fonts/Roboto-BoldItalic.94008e69.woff2"
  },
  {
    "revision": "4fe0f73cc919ba2b7a3c36e4540d725c",
    "url": "/fonts/Roboto-BoldItalic.4fe0f73c.woff"
  },
  {
    "revision": "59eb3601394dd87f30f82433fb39dd94",
    "url": "/fonts/Roboto-Black.59eb3601.woff2"
  },
  {
    "revision": "313a65630d341645c13e4f2a0364381d",
    "url": "/fonts/Roboto-Black.313a6563.woff"
  },
  {
    "revision": "f75569f8a5fab0893fa712d8c0d9c3fe",
    "url": "/fonts/Roboto-BlackItalic.f75569f8.woff2"
  },
  {
    "revision": "cc2fadc3928f2f223418887111947b40",
    "url": "/fonts/Roboto-BlackItalic.cc2fadc3.woff"
  },
  {
    "revision": "eeaa9f3dc8212e210b33f6b203ce8426",
    "url": "/img/map_ship.eeaa9f3d.png"
  },
  {
    "revision": "17bdd48f15c68d92d0a4258e2c2c343a",
    "url": "/img/cloud_left.17bdd48f.svg"
  },
  {
    "revision": "5930ff0ec8df4e7eeb5ce1e2c684997d",
    "url": "/img/footer_foreground.5930ff0e.svg"
  },
  {
    "revision": "602cf360012ae2e890c00c2b3fd50463",
    "url": "/img/bg_maintenance.602cf360.svg"
  },
  {
    "revision": "dcc98672a0114a063ff0871c1406f308",
    "url": "/img/icon_white_line.dcc98672.svg"
  },
  {
    "revision": "76a479d9b077f5edca1a8e88a62bfb0f",
    "url": "/img/footer_background.76a479d9.svg"
  },
  {
    "revision": "28822f791248b54df45b5f1666618565",
    "url": "/img/map_position.28822f79.png"
  },
  {
    "revision": "2b3fcde58af5d2b70a2cae73b87f2925",
    "url": "/img/logo_vertical.2b3fcde5.svg"
  },
  {
    "revision": "256a75a236de69ba8abcdef28b1d8221",
    "url": "/img/icon_position.256a75a2.svg"
  },
  {
    "revision": "e3e1c5140f31a46dd2e1e6098ba78d72",
    "url": "/img/cloud02.e3e1c514.png"
  },
  {
    "revision": "6243d3833e5ae5a188b026ebe50b6e1d",
    "url": "/img/icon_email.6243d383.svg"
  },
  {
    "revision": "731acf6865271ee7439c996aa3cd58a0",
    "url": "/index.html"
  },
  {
    "revision": "682cafea2ac9d4b0d13863977c9454a7",
    "url": "/CustomEase.min.js"
  },
  {
    "revision": "4981aad6ae4562d777c84c0246e243a6",
    "url": "/img/banner/banner001.jpg"
  },
  {
    "revision": "f86705b7883c8ad4ecfdca3d03dda440",
    "url": "/img/banner/banner003.jpg"
  },
  {
    "revision": "135de449b014bfbf1455b98e52bc85b6",
    "url": "/img/banner/banner004.jpg"
  },
  {
    "revision": "97c6d1a4793d8a5d80222415a09cc29b",
    "url": "/img/banner/banner005.jpg"
  },
  {
    "revision": "33bbacc3a3cb302fd66b43e498a18112",
    "url": "/img/banner/banner002.jpg"
  },
  {
    "revision": "c4ec317578d063a79397918350aeed4d",
    "url": "/img/follow/ad_sm002.jpg"
  },
  {
    "revision": "3b20876c092ade1af3510ac3aa3f0035",
    "url": "/img/bg_image/bg_haveFun.jpg"
  },
  {
    "revision": "8ead59b72f38856cc06361b002d722be",
    "url": "/img/follow/ad_sm001.jpg"
  },
  {
    "revision": "23c86ad577fab4104789b1a76cc0e833",
    "url": "/img/bg_image/bg_order.png"
  },
  {
    "revision": "3a3e5aa23ba26299d0bf35d46a6efb4c",
    "url": "/img/follow/ad_sm003.jpg"
  },
  {
    "revision": "5d45f0630b445173eeea45f623d5ef5c",
    "url": "/img/follow/follow-phelomi01.jpg"
  },
  {
    "revision": "2867fde354b424e8bf9f95b381be48f5",
    "url": "/img/follow/follow-phelomi03.jpg"
  },
  {
    "revision": "446e83af28270c15579738ce7083cd29",
    "url": "/img/follow/follow-phelomi02.jpg"
  },
  {
    "revision": "8471e557445f610955a02784f50d2142",
    "url": "/img/follow/follow-phelomi04.jpg"
  },
  {
    "revision": "d2a9ee38ab5f3a0cd36da2bac9f35fbf",
    "url": "/img/follow/follow-phelomi05.jpg"
  },
  {
    "revision": "d059562047873e0e93781223050974e4",
    "url": "/img/img_sm/news002.jpg"
  },
  {
    "revision": "dfb5f1bea35e21f54264389c77728894",
    "url": "/img/img_sm/news003.jpg"
  },
  {
    "revision": "cc9a7323e3599f53ff59f5200cae47c6",
    "url": "/img/img_sm/placeholder.jpg"
  },
  {
    "revision": "8040542519ed46f3f3dbc5608c3e012f",
    "url": "/img/img_sm/PengHoFunSummer.jpg"
  },
  {
    "revision": "db3b10a9add92d1a21bb279e92f240bf",
    "url": "/img/img_sm/SpSales.jpg"
  },
  {
    "revision": "e5a0868f07e249ed4a3cf0d9c826dca6",
    "url": "/img/news/music2019.jpg"
  },
  {
    "revision": "f64f4388336d87cae4b5c92bc9d17aa8",
    "url": "/img/rooms_sm/a2-atlantic.jpg"
  },
  {
    "revision": "5500470ed59c4eabb4f57df259abceb7",
    "url": "/img/news/new-ship.jpg"
  },
  {
    "revision": "0e93e6e3703049ca3b14b60ea5c07bfe",
    "url": "/img/rooms_sm/a2-indian-ocean.jpg"
  },
  {
    "revision": "e4db89791e97552ee5b7d5f1fac7c465",
    "url": "/img/news/201907Summer.jpg"
  },
  {
    "revision": "8fd4233e6093f46bf9d38b4cbdc64980",
    "url": "/img/rooms_sm/a2-coral-sea.jpg"
  },
  {
    "revision": "9142526169d29096dd65e47f9f5ae683",
    "url": "/img/rooms_sm/a2-the-pacific-ocean.jpg"
  },
  {
    "revision": "099a9a4eb4b3aa4f9b41bfd5d60200b2",
    "url": "/img/rooms_sm/a2-irish-sea.jpg"
  },
  {
    "revision": "f6c04ed204c13195b4e8afaa73370a16",
    "url": "/img/rooms_sm/a4-aegean-sea.jpg"
  },
  {
    "revision": "05b10088b1b70f01552a15b37071a601",
    "url": "/img/rooms_sm/a4-arctic-ocean.jpg"
  },
  {
    "revision": "faece89633d96de80a4ce3618f44e8e2",
    "url": "/img/rooms_sm/b2-sky-blue.jpg"
  },
  {
    "revision": "b8f114484462dbe0854952971566cbf0",
    "url": "/img/rooms_sm/b4-apple-green.jpg"
  },
  {
    "revision": "1aac85b5958d08630d4d722f3f95c311",
    "url": "/img/rooms_sm/b4-chestnut-red.jpg"
  },
  {
    "revision": "ffc3368579b744637639c2e1c6ba551a",
    "url": "/img/rooms_sm/b4-cocoa.jpg"
  },
  {
    "revision": "89197c4f7093740db34589b2ffcec448",
    "url": "/img/rooms_sm/b4-orange-and-orange.jpg"
  },
  {
    "revision": "dfef8a25449a31ac253ea275f077c4fd",
    "url": "/img/rooms_sm/b4-violet.jpg"
  },
  {
    "revision": "0faa0a38868620067384100eee68eb2e",
    "url": "/img/rooms_sm/b4-coral-sea.jpg"
  },
  {
    "revision": "884ee8ccb033b1d02dc3c09f460d9112",
    "url": "/img/rooms/afao/afao01.jpg"
  },
  {
    "revision": "ac8d09f47a75d82282374a0fd8e71724",
    "url": "/img/rooms/afao/afao02.jpg"
  },
  {
    "revision": "5be31801636ee96e80a6970a7105fd1c",
    "url": "/img/rooms/afao/afao03.jpg"
  },
  {
    "revision": "d8d0e9918afeaef529ad2998f7d84e6c",
    "url": "/img/rooms/afas/afas01.jpg"
  },
  {
    "revision": "e6abbc09d5a99ebf8f555afdcbf42c99",
    "url": "/img/rooms/afao/afao04.jpg"
  },
  {
    "revision": "5551333d64dfb2f74dc36c88dd590cc1",
    "url": "/img/rooms/afas/afas04.jpg"
  },
  {
    "revision": "283afda1bcf5dabab2602d4d98744bd9",
    "url": "/img/rooms/afas/afas02.jpg"
  },
  {
    "revision": "5cfc5ed1f03056368fe5c39af11eed36",
    "url": "/img/rooms/afas/afas03.jpg"
  },
  {
    "revision": "37fbc59631f7da69994ded6b3cc6c9df",
    "url": "/img/rooms/ata/ata01.jpg"
  },
  {
    "revision": "25d1f405c1d9aef9ea03bb11e2a8f7db",
    "url": "/img/rooms/atcs/atcs01.jpg"
  },
  {
    "revision": "74265def5034c36788060abf65a3e6df",
    "url": "/img/rooms/ata/ata02.jpg"
  },
  {
    "revision": "ac1fb6b68cd938024f4f3d492ef59a71",
    "url": "/img/rooms/ata/ata03.jpg"
  },
  {
    "revision": "49b8fb256f9e46253437b421169481e7",
    "url": "/img/rooms/atcs/atcs03.jpg"
  },
  {
    "revision": "60d3647102d094a6b96b5f0572f28400",
    "url": "/img/rooms/atio/atio01.jpg"
  },
  {
    "revision": "c66c5918a39ccb2a45012299f80221e4",
    "url": "/img/rooms/atcs/atcs02.jpg"
  },
  {
    "revision": "0727ac42fe598cbd68aec3ca3c6eb7ca",
    "url": "/img/rooms/atio/atio02.jpg"
  },
  {
    "revision": "42a9d4cb52d8f370128ba6fa6f8148b7",
    "url": "/img/rooms/atcs/atcs04.jpg"
  },
  {
    "revision": "61e46be4ef59fd10f097a1e8ed2f5907",
    "url": "/img/rooms/atis/atis01.jpg"
  },
  {
    "revision": "1f18c806a4c049013c67b22f129f1c1f",
    "url": "/img/rooms/atio/atio03.jpg"
  },
  {
    "revision": "3c1701fc8e72f13cd6568c4545d8e1fd",
    "url": "/img/rooms/atis/atis03.jpg"
  },
  {
    "revision": "a3b434fc18aee0cdbad29599f50250e7",
    "url": "/img/rooms/atio/atio04.jpg"
  },
  {
    "revision": "6716750c2edcd70094dbb9e60a3f79ab",
    "url": "/img/rooms/atis/atis02.jpg"
  },
  {
    "revision": "0a0c7742ce29a9896b97c55f5df78152",
    "url": "/img/rooms/atpo/atpo01.jpg"
  },
  {
    "revision": "1fc4a84d5d711061a0c08bb1d0b6827b",
    "url": "/img/rooms/atpo/atpo02.jpg"
  },
  {
    "revision": "f547d239535356c5f039f4e4781ff9f3",
    "url": "/img/rooms/atpo/atpo03.jpg"
  },
  {
    "revision": "7ad770536249b82aeb752b652201af73",
    "url": "/img/rooms/bfag/bfag01.jpg"
  },
  {
    "revision": "725ad0040f3e38979e8f543d6c32043e",
    "url": "/img/rooms/bfag/bfag02.jpg"
  },
  {
    "revision": "1bd6202aa2490d30acc5f2f9be437346",
    "url": "/img/rooms/bfc/bfc01.jpg"
  },
  {
    "revision": "0fe94c5f172b0bbb26b87132affd439d",
    "url": "/img/rooms/bfag/bfag03.jpg"
  },
  {
    "revision": "25516972387e3d6a542c23508f98b032",
    "url": "/img/rooms/atis/atis04.jpg"
  },
  {
    "revision": "cab1daa384595a5d2c9d65df5ef128c0",
    "url": "/img/rooms/bfc/bfc02.jpg"
  },
  {
    "revision": "5294a9b82214757c069b16ed99ef61a8",
    "url": "/img/rooms/bfag/bfag04.JPG"
  },
  {
    "revision": "384fa4e52723cb741ca01178363b9b92",
    "url": "/img/rooms/bfc/bfc04.jpg"
  },
  {
    "revision": "09c7d6b00a7090487cff469357d670c4",
    "url": "/img/rooms/bfcp/bfcp01.jpg"
  },
  {
    "revision": "e5019baaf0c9fc802ec54b37cab84a61",
    "url": "/img/rooms/bfc/bfc03.jpg"
  },
  {
    "revision": "590e9cdc2c66becd763d9d5bd1f84aff",
    "url": "/img/rooms/bfcp/bfcp03.jpg"
  },
  {
    "revision": "d61fd875f34977e4c3b1d957cae675b3",
    "url": "/img/rooms/bfcp/bfcp02.jpg"
  },
  {
    "revision": "d7d7ec7c0a49a32efb4670c659183ce9",
    "url": "/img/rooms/bfcr/bfcr01.jpg"
  },
  {
    "revision": "1c0fff45a4778ea450f4ae17623ca483",
    "url": "/img/rooms/bfcp/bfcp04.jpg"
  },
  {
    "revision": "7d9a9ab0de70a1a34fad9fcef07ce736",
    "url": "/img/rooms/bfcr/bfcr02.jpg"
  },
  {
    "revision": "059c1bc060e496bb1326e886e88938ce",
    "url": "/img/rooms/bfcr/bfcr04.jpg"
  },
  {
    "revision": "2fcc789c5afa2c0df01956b76a3863f8",
    "url": "/img/rooms/bfcr/bfcr03.jpg"
  },
  {
    "revision": "6bc827a5e150fd42f2b6842e44833185",
    "url": "/img/rooms/bfoo/bfoo04.jpg"
  },
  {
    "revision": "18a5ecb57d3ea4a487c4ec1f6e0611bc",
    "url": "/img/rooms/bfoo/bfoo02.jpg"
  },
  {
    "revision": "42a09dfb585dce1bc8ca3788f519151c",
    "url": "/img/rooms/bfoo/bfoo03.jpg"
  },
  {
    "revision": "030ca575d4735d489463b09c550dffd4",
    "url": "/img/rooms/bfoo/bfoo01.jpg"
  },
  {
    "revision": "9cb667b190b299c06b8e4f63221eb186",
    "url": "/img/rooms/bfv/bfv02.jpg"
  },
  {
    "revision": "aa1e27bfaeecc7a37f1025caba484021",
    "url": "/img/rooms/bfv/bfv01.jpg"
  },
  {
    "revision": "3d53d74ea462ab8290add7f5d4d934d7",
    "url": "/img/rooms/atpo/atpo04.jpg"
  },
  {
    "revision": "694aa8786e7d8837d2bd08fc2911ddd5",
    "url": "/img/rooms/bfv/bfv04.jpg"
  },
  {
    "revision": "6486f76bd9500074aa3a3a3122f03609",
    "url": "/img/rooms/btsb/btsb02.jpg"
  },
  {
    "revision": "8dfbcf5ffee12d62024c4b829c1165d7",
    "url": "/img/rooms/bfv/bfv03.jpg"
  },
  {
    "revision": "67562076dc4f4d488062b4de2419fece",
    "url": "/img/rooms/btsb/btsb01.jpg"
  },
  {
    "revision": "837bd6f5077125b6a685ee233f476ba7",
    "url": "/img/rooms/icon/icon-shower.svg"
  },
  {
    "revision": "2b9f1efcfb8cc69c5c8ff4a70d5d3f51",
    "url": "/img/rooms/icon/icon-tea.svg"
  },
  {
    "revision": "69e7950473f3de7f11a5249d75538a16",
    "url": "/img/rooms/icon/icon-tv.svg"
  },
  {
    "revision": "6f12ca647fba5f56686767bd670945dd",
    "url": "/img/rooms/btsb/btsb03.jpg"
  },
  {
    "revision": "631f05a9ca553e89dfa8ef96b22d27b7",
    "url": "/img/rooms/icon/icon-wifi.svg"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "29a9a4963a373308de7b6b109e1f5d91",
    "url": "/img/rooms/btsb/btsb04.jpg"
  }
];