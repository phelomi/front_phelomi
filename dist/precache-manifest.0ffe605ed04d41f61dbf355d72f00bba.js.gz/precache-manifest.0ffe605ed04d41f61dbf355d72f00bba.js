self.__precacheManifest = [
  {
    "revision": "94c9c6ca90f59c24455c22a426f31675",
    "url": "/img/icon_ship.94c9c6ca.svg"
  },
  {
    "revision": "3d53d74ea462ab8290add7f5d4d934d7",
    "url": "/img/rooms/atpo/atpo04.jpg"
  },
  {
    "revision": "d7920a0bd71ef08ee029",
    "url": "/js/chunk-0635b894.4334bff5.js"
  },
  {
    "revision": "9e22342bd0ac598e2c4c",
    "url": "/js/chunk-077f7e84.36c94e45.js"
  },
  {
    "revision": "96e2dfbaf2c268938a09bcdb37720323",
    "url": "/img/rooms/bfv/bfv03.jpg"
  },
  {
    "revision": "14ab431280c95d8689d6",
    "url": "/js/chunk-187f2124.d569c658.js"
  },
  {
    "revision": "96e2dfbaf2c268938a09bcdb37720323",
    "url": "/img/rooms/bfcp/bfcp02.jpg"
  },
  {
    "revision": "3f7ad64345bd9b6644c4",
    "url": "/js/chunk-22d5a82a.398bb7a0.js"
  },
  {
    "revision": "96e2dfbaf2c268938a09bcdb37720323",
    "url": "/img/rooms/bfc/bfc03.jpg"
  },
  {
    "revision": "1c6f2a2d22ae19761275",
    "url": "/js/chunk-23a2ccf2.3a125792.js"
  },
  {
    "revision": "0479d2701498761e9a24",
    "url": "/js/chunk-2d0a4296.6a251593.js"
  },
  {
    "revision": "9011e0e51d94d69b1a3a",
    "url": "/js/chunk-2d0aa7aa.866a24c1.js"
  },
  {
    "revision": "8edaf246e060fb8f1b42",
    "url": "/js/chunk-2d0af63f.041ec3ff.js"
  },
  {
    "revision": "b6617d4b5e72bea7dd1a",
    "url": "/js/chunk-2d0b3430.71ad9807.js"
  },
  {
    "revision": "047199bb2ce7ec12a448",
    "url": "/js/chunk-2d0b7259.d8cb1cbd.js"
  },
  {
    "revision": "450c36648d5cb6190cf0",
    "url": "/js/chunk-2d0b99e6.ff3cb423.js"
  },
  {
    "revision": "1205af936cb523358b90",
    "url": "/js/chunk-2d0ba690.c1ad6814.js"
  },
  {
    "revision": "7530117705ae5404e0bd",
    "url": "/js/chunk-2d0bd5a9.c0c80d40.js"
  },
  {
    "revision": "b869aa55bc4c05d88128",
    "url": "/js/chunk-2d0c1216.3ad4c7b2.js"
  },
  {
    "revision": "e6360678906756eb2516",
    "url": "/js/chunk-2d0c18ec.89bae00d.js"
  },
  {
    "revision": "e0173d4ba858b4210815",
    "url": "/js/chunk-2d0c1d75.b37c6c8e.js"
  },
  {
    "revision": "c3af7443400e9f5aa2c0",
    "url": "/js/chunk-2d0c517c.5c180172.js"
  },
  {
    "revision": "5455d7861ccdde3e0860",
    "url": "/js/chunk-2d0c9b38.15222af5.js"
  },
  {
    "revision": "7ea23f764a48b58c7530",
    "url": "/js/chunk-2d0cef72.3e376deb.js"
  },
  {
    "revision": "1e1240c2ebe03e56a317",
    "url": "/js/chunk-2d0d0042.e76cef2f.js"
  },
  {
    "revision": "d127d8026f9caecaaae5",
    "url": "/js/chunk-2d0d01cb.86a1077b.js"
  },
  {
    "revision": "d5a2b07d79af37296472",
    "url": "/js/chunk-2d0d05d3.788e2621.js"
  },
  {
    "revision": "a304a28b77353244e7ac",
    "url": "/js/chunk-2d0d3dd9.464b4a9c.js"
  },
  {
    "revision": "367c4c3993ae5c259603",
    "url": "/js/chunk-2d0d43ea.98ff2577.js"
  },
  {
    "revision": "8bfb0b25653576c56b58",
    "url": "/js/chunk-2d0d643d.8f254946.js"
  },
  {
    "revision": "4b15abad5076b2a50651",
    "url": "/js/chunk-2d0d76f5.f09d0b55.js"
  },
  {
    "revision": "1722561fa6880ff13319",
    "url": "/js/chunk-2d0dd0e9.aa126989.js"
  },
  {
    "revision": "8f08e94ed1f3ae71300a",
    "url": "/js/chunk-2d0dd7b6.440079b6.js"
  },
  {
    "revision": "dbd68d187ba0b1bfc7c3",
    "url": "/js/chunk-2d0dee78.ba847bbc.js"
  },
  {
    "revision": "dbd81f236e5da351ca36",
    "url": "/js/chunk-2d0df0c5.016d973d.js"
  },
  {
    "revision": "1c3807d995fab87c01bd",
    "url": "/js/chunk-2d0e5983.5b37308d.js"
  },
  {
    "revision": "1ac4868db4bdeab59043",
    "url": "/js/chunk-2d0e5bcf.45ff77a1.js"
  },
  {
    "revision": "1ae3eb204528a26a5d8d",
    "url": "/js/chunk-2d0e5f64.8a3aa77d.js"
  },
  {
    "revision": "d15eccccc87d2e5b795b",
    "url": "/js/chunk-2d0e91b6.3cb369bd.js"
  },
  {
    "revision": "46db9eefdbe77dbb8238",
    "url": "/js/chunk-2d0f11e1.d3951c40.js"
  },
  {
    "revision": "1c6c626d8105452e2ac1",
    "url": "/js/chunk-2d20efc9.28b0ffe0.js"
  },
  {
    "revision": "976f15b7e2afdd63576d",
    "url": "/js/chunk-2d21765f.7c3fcfa3.js"
  },
  {
    "revision": "8b32163cecc8f0693233",
    "url": "/js/chunk-2d21df49.7438fc68.js"
  },
  {
    "revision": "3e7812c7cef1f4027647",
    "url": "/js/chunk-2d21e72d.badff106.js"
  },
  {
    "revision": "85c5554fd5a6252c69fd",
    "url": "/js/chunk-2d21e73b.d83deb78.js"
  },
  {
    "revision": "dfcf284470378a941178",
    "url": "/js/chunk-2d21eaec.5c86d9ac.js"
  },
  {
    "revision": "49def203af750b699ea4",
    "url": "/js/chunk-2d221836.ff6f48fc.js"
  },
  {
    "revision": "df08ebd8ed3570741a70",
    "url": "/js/chunk-2d224c47.0c2dd9d9.js"
  },
  {
    "revision": "f5f5b42210a09ddc056d",
    "url": "/js/chunk-2d226365.3a8572a8.js"
  },
  {
    "revision": "250758c4d5941c1d2377",
    "url": "/js/chunk-2d2288f6.a15a16ba.js"
  },
  {
    "revision": "7e2d5affce24d2986813",
    "url": "/js/chunk-2d22998c.bb0497cd.js"
  },
  {
    "revision": "d18637d5c3a07eaf39f2",
    "url": "/js/chunk-2d22c342.3838dc45.js"
  },
  {
    "revision": "0e848b722000dceba9ed",
    "url": "/js/chunk-2d22c8c0.d00d2fde.js"
  },
  {
    "revision": "0fbbdaf09ae7f8d67952",
    "url": "/js/chunk-2d22d09e.5d2fb433.js"
  },
  {
    "revision": "2ec9033df047812c1365",
    "url": "/js/chunk-2d22dd18.83cbb394.js"
  },
  {
    "revision": "4b773d9e4cfabe253a6e",
    "url": "/js/chunk-2d22fdaf.dc1c0c87.js"
  },
  {
    "revision": "de76eacda4807b5e2479",
    "url": "/js/chunk-2d2311e3.80d30033.js"
  },
  {
    "revision": "f9c7db1c09d2c542eca2",
    "url": "/js/chunk-37ed12e5.43659460.js"
  },
  {
    "revision": "ad6b53aba9767cc5ec99",
    "url": "/js/chunk-47d6abce.76181bac.js"
  },
  {
    "revision": "c378207822de871e94a4",
    "url": "/js/chunk-4d92f04a.d048a2ec.js"
  },
  {
    "revision": "07415edb40ff27615668",
    "url": "/js/chunk-513e2f9c.40ddaefb.js"
  },
  {
    "revision": "c54f7dca9d3bcd384994",
    "url": "/js/chunk-544611b3.abb61b61.js"
  },
  {
    "revision": "7738ffaf598eb458af65",
    "url": "/js/chunk-562015c0.f863891d.js"
  },
  {
    "revision": "e893c4b5e89ecc97477a",
    "url": "/js/chunk-5e4c12fe.4afb8efe.js"
  },
  {
    "revision": "20eef5149b70017c73b7",
    "url": "/js/chunk-5e4f6c72.34b2a884.js"
  },
  {
    "revision": "2074763d46181dd7efdb",
    "url": "/js/chunk-63d65b8d.7c84119f.js"
  },
  {
    "revision": "0b6c8e62f66165199dc1",
    "url": "/js/chunk-685b0b4c.c9b96089.js"
  },
  {
    "revision": "56f2aa98308c4db87d9a",
    "url": "/js/chunk-6c729a06.51a66caf.js"
  },
  {
    "revision": "42a09dfb585dce1bc8ca3788f519151c",
    "url": "/img/rooms/bfoo/bfoo03.jpg"
  },
  {
    "revision": "c19c266c02b72c75f31d",
    "url": "/js/chunk-74544e1f.a275929f.js"
  },
  {
    "revision": "c83ef2bee63f364f0dd2",
    "url": "/js/chunk-74597ca9.8ff92239.js"
  },
  {
    "revision": "7ad770536249b82aeb752b652201af73",
    "url": "/img/rooms/bfag/bfag01.jpg"
  },
  {
    "revision": "3e3e229750919cd6c331",
    "url": "/js/chunk-746799a8.eacdde9d.js"
  },
  {
    "revision": "29a9a4963a373308de7b6b109e1f5d91",
    "url": "/img/rooms/btsb/btsb04.jpg"
  },
  {
    "revision": "49166fedb4131f75b215",
    "url": "/js/chunk-74693142.5ec443bd.js"
  },
  {
    "revision": "5294a9b82214757c069b16ed99ef61a8",
    "url": "/img/rooms/bfag/bfag04.JPG"
  },
  {
    "revision": "4320d321b75f98c0a3a2",
    "url": "/js/chunk-74697fd9.f4e47304.js"
  },
  {
    "revision": "0fe94c5f172b0bbb26b87132affd439d",
    "url": "/img/rooms/bfag/bfag03.jpg"
  },
  {
    "revision": "9c564d8e93f7d6cfe5e1",
    "url": "/js/chunk-746f9064.712b0eb7.js"
  },
  {
    "revision": "67562076dc4f4d488062b4de2419fece",
    "url": "/img/rooms/btsb/btsb01.jpg"
  },
  {
    "revision": "d5bf659b2d13f70f0a2d",
    "url": "/js/chunk-74704285.c9d0890f.js"
  },
  {
    "revision": "18a5ecb57d3ea4a487c4ec1f6e0611bc",
    "url": "/img/rooms/bfoo/bfoo02.jpg"
  },
  {
    "revision": "9f7635024ca49c675ad2",
    "url": "/js/chunk-7475f6ab.4778328c.js"
  },
  {
    "revision": "725ad0040f3e38979e8f543d6c32043e",
    "url": "/img/rooms/bfag/bfag02.jpg"
  },
  {
    "revision": "13e1aa9f8cb59bd85a05",
    "url": "/js/chunk-7476dfa7.71e7a39f.js"
  },
  {
    "revision": "6486f76bd9500074aa3a3a3122f03609",
    "url": "/img/rooms/btsb/btsb02.jpg"
  },
  {
    "revision": "58b1cb5de4346046cdab",
    "url": "/js/chunk-7477fe0a.21b4d708.js"
  },
  {
    "revision": "6f12ca647fba5f56686767bd670945dd",
    "url": "/img/rooms/btsb/btsb03.jpg"
  },
  {
    "revision": "bca0107a988e5d45778d",
    "url": "/js/chunk-747d763f.6163d8de.js"
  },
  {
    "revision": "2fcc789c5afa2c0df01956b76a3863f8",
    "url": "/img/rooms/bfcr/bfcr03.jpg"
  },
  {
    "revision": "b36b9836f75281c22331",
    "url": "/js/chunk-7482abbb.558a7806.js"
  },
  {
    "revision": "d7d7ec7c0a49a32efb4670c659183ce9",
    "url": "/img/rooms/bfcr/bfcr01.jpg"
  },
  {
    "revision": "432d932cfef90e7686f2",
    "url": "/js/chunk-7484083d.26d333bb.js"
  },
  {
    "revision": "030ca575d4735d489463b09c550dffd4",
    "url": "/img/rooms/bfoo/bfoo01.jpg"
  },
  {
    "revision": "8232cd625bab1f5768ab",
    "url": "/js/chunk-74847767.497b814a.js"
  },
  {
    "revision": "a8d9fd92780e105084dbb933269ad5bb",
    "url": "/img/rooms/bfcp/bfcp01.jpg"
  },
  {
    "revision": "85b2d9b109b99f84ea0e",
    "url": "/js/chunk-748a351e.741577eb.js"
  },
  {
    "revision": "eaa04fe9dfe05743822ee8c4d0aa13cb",
    "url": "/img/rooms/bfc/bfc02.jpg"
  },
  {
    "revision": "e570e0a516c3f05c8d31",
    "url": "/js/chunk-74b10368.d3dde2c7.js"
  },
  {
    "revision": "e0c66f496a9bfb791dd2",
    "url": "/js/chunk-74b64517.4d3f92ac.js"
  },
  {
    "revision": "059c1bc060e496bb1326e886e88938ce",
    "url": "/img/rooms/bfcr/bfcr04.jpg"
  },
  {
    "revision": "29fdd09f8d116d41c776",
    "url": "/js/chunk-74b6f911.5d9692cf.js"
  },
  {
    "revision": "6bc827a5e150fd42f2b6842e44833185",
    "url": "/img/rooms/bfoo/bfoo04.jpg"
  },
  {
    "revision": "b9e35cc6b12dcc654a37",
    "url": "/js/chunk-74bc2e8d.d8dd6769.js"
  },
  {
    "revision": "cebaf4a9fab4ab7615f8cf8e593db34e",
    "url": "/img/rooms/bfc/bfc01.jpg"
  },
  {
    "revision": "54adc26ac13982921fb1",
    "url": "/js/chunk-74bcdefc.00985959.js"
  },
  {
    "revision": "7d9a9ab0de70a1a34fad9fcef07ce736",
    "url": "/img/rooms/bfcr/bfcr02.jpg"
  },
  {
    "revision": "74e54790d32739a90ff7",
    "url": "/js/chunk-74d2b031.d01018a8.js"
  },
  {
    "revision": "c8910bac61c8b60c58a03188d4cc1336",
    "url": "/img/rooms/bfv/bfv02.jpg"
  },
  {
    "revision": "b7f6fa41a5c23d3d9c32",
    "url": "/js/chunk-76f13012.e450daaf.js"
  },
  {
    "revision": "294ba4310b25c8b42c647e27dc51cb6e",
    "url": "/img/rooms/bfv/bfv01.jpg"
  },
  {
    "revision": "fd02296e2d46eccf2344",
    "url": "/js/chunk-76f25df5.5a792133.js"
  },
  {
    "revision": "69e7950473f3de7f11a5249d75538a16",
    "url": "/img/rooms/icon/icon-tv.svg"
  },
  {
    "revision": "1001d9a612a973a95629",
    "url": "/js/chunk-76fe9cf4.694c4615.js"
  },
  {
    "revision": "631f05a9ca553e89dfa8ef96b22d27b7",
    "url": "/img/rooms/icon/icon-wifi.svg"
  },
  {
    "revision": "a0210b799d69b57e1f16",
    "url": "/js/chunk-770e1ae5.3cd933c5.js"
  },
  {
    "revision": "837bd6f5077125b6a685ee233f476ba7",
    "url": "/img/rooms/icon/icon-shower.svg"
  },
  {
    "revision": "2eb26b7547b91e485987",
    "url": "/js/chunk-7718b8f7.817d8743.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "fa5305ad9dc2a8b0e42e",
    "url": "/js/chunk-771afaf2.7c7849fe.js"
  },
  {
    "revision": "2b9f1efcfb8cc69c5c8ff4a70d5d3f51",
    "url": "/img/rooms/icon/icon-tea.svg"
  },
  {
    "revision": "010aa1ffe57d99a5150d",
    "url": "/js/chunk-772256ae.0dad4675.js"
  },
  {
    "revision": "dfef8a25449a31ac253ea275f077c4fd",
    "url": "/img/rooms_sm/b4-violet.jpg"
  },
  {
    "revision": "6fbc05294fe93258798b",
    "url": "/js/chunk-7722bfab.5a9cb634.js"
  },
  {
    "revision": "ffc3368579b744637639c2e1c6ba551a",
    "url": "/img/rooms_sm/b4-cocoa.jpg"
  },
  {
    "revision": "9fc70d798bcb92abcfd4",
    "url": "/js/chunk-77271350.8c3c1223.js"
  },
  {
    "revision": "f6c04ed204c13195b4e8afaa73370a16",
    "url": "/img/rooms_sm/a4-aegean-sea.jpg"
  },
  {
    "revision": "4bbbf7cf184479a6b392",
    "url": "/js/chunk-772efa8c.b8df72c0.js"
  },
  {
    "revision": "8876a991cedfa69b42de",
    "url": "/js/chunk-7c9a87de.47e995df.js"
  },
  {
    "revision": "db78d37db28b5696f05d",
    "url": "/js/chunk-90680f3c.c844d9b9.js"
  },
  {
    "revision": "1fbde47f1f67c05c5528",
    "url": "/js/chunk-ca460650.0bb16bd1.js"
  },
  {
    "revision": "b8f114484462dbe0854952971566cbf0",
    "url": "/img/rooms_sm/b4-apple-green.jpg"
  },
  {
    "revision": "8a7186d9a23f025b3f2f",
    "url": "/js/chunk-vendors.966a3201.js"
  },
  {
    "revision": "6a107b2bf6c9c0981087",
    "url": "/js/error.3467fb79.js"
  },
  {
    "revision": "f48e746fc0c2358b4390",
    "url": "/js/follow.951b87bc.js"
  },
  {
    "revision": "faece89633d96de80a4ce3618f44e8e2",
    "url": "/img/rooms_sm/b2-sky-blue.jpg"
  },
  {
    "revision": "6280313be3411d62c1cb",
    "url": "/js/follow~home~news~rooms.64cbbca2.js"
  },
  {
    "revision": "0f1638729f1668113ad1",
    "url": "/js/home.6ca7266c.js"
  },
  {
    "revision": "e3f32fa0e2381ffe8901",
    "url": "/js/location.9883b784.js"
  },
  {
    "revision": "61fa152f4eb2cfcf7227",
    "url": "/js/maintenance.a22b680c.js"
  },
  {
    "revision": "e14546fb27915b8fc6a0",
    "url": "/js/news.7d772313.js"
  },
  {
    "revision": "690e0b1ef22b6c37d841",
    "url": "/js/rooms.c1304a31.js"
  },
  {
    "revision": "9142526169d29096dd65e47f9f5ae683",
    "url": "/img/rooms_sm/a2-the-pacific-ocean.jpg"
  },
  {
    "revision": "099a9a4eb4b3aa4f9b41bfd5d60200b2",
    "url": "/img/rooms_sm/a2-irish-sea.jpg"
  },
  {
    "revision": "05b10088b1b70f01552a15b37071a601",
    "url": "/img/rooms_sm/a4-arctic-ocean.jpg"
  },
  {
    "revision": "8fd4233e6093f46bf9d38b4cbdc64980",
    "url": "/img/rooms_sm/a2-coral-sea.jpg"
  },
  {
    "revision": "0e93e6e3703049ca3b14b60ea5c07bfe",
    "url": "/img/rooms_sm/a2-indian-ocean.jpg"
  },
  {
    "revision": "f64f4388336d87cae4b5c92bc9d17aa8",
    "url": "/img/rooms_sm/a2-atlantic.jpg"
  },
  {
    "revision": "89197c4f7093740db34589b2ffcec448",
    "url": "/img/rooms_sm/b4-orange-and-orange.jpg"
  },
  {
    "revision": "0faa0a38868620067384100eee68eb2e",
    "url": "/img/rooms_sm/b4-coral-sea.jpg"
  },
  {
    "revision": "1aac85b5958d08630d4d722f3f95c311",
    "url": "/img/rooms_sm/b4-chestnut-red.jpg"
  },
  {
    "revision": "5582497245d2b09da0d629a03d2fbd6b",
    "url": "/img/text-order.55824972.png"
  },
  {
    "revision": "6f171a9b3314fe4731061d9bff383abe",
    "url": "/img/titleBoatStar.6f171a9b.svg"
  },
  {
    "revision": "346769a35e9f19e119f6",
    "url": "/js/app.493264af.js"
  },
  {
    "revision": "6280313be3411d62c1cb",
    "url": "/css/follow~home~news~rooms.4715f0d9.css"
  },
  {
    "revision": "0ce8075c6af52188e3fa315bf513dcba",
    "url": "/img/bg_location.0ce8075c.jpg"
  },
  {
    "revision": "1a57ca49ecd7b8525f6e34a53997c1ae",
    "url": "/img/cloud_center.1a57ca49.svg"
  },
  {
    "revision": "9ecd4117411947f4692af455ec2f6358",
    "url": "/img/icon_wechat.9ecd4117.svg"
  },
  {
    "revision": "cc9a7323e3599f53ff59f5200cae47c6",
    "url": "/img/placeholder.cc9a7323.jpg"
  },
  {
    "revision": "2f9012a08131ed40a1e25849752f75a9",
    "url": "/img/icon_header.2f9012a0.svg"
  },
  {
    "revision": "5b9d462610122986d007270cf51702cc",
    "url": "/img/icon_airplane.5b9d4626.svg"
  },
  {
    "revision": "c9e81a3156d5be091a77a011921ee46d",
    "url": "/img/icon_instagram.c9e81a31.svg"
  },
  {
    "revision": "7de27202d8ac2f321133ba78534d4df0",
    "url": "/img/icon_white_wechat.7de27202.svg"
  },
  {
    "revision": "541e9e83c9e32f084d7f336c7de46ab8",
    "url": "/img/cloud_right.541e9e83.svg"
  },
  {
    "revision": "ec821ecaa7872d34aab24409d2371efd",
    "url": "/img/icon_airplane.ec821eca.svg"
  },
  {
    "revision": "e4db89791e97552ee5b7d5f1fac7c465",
    "url": "/img/news/201907Summer.jpg"
  },
  {
    "revision": "df632b4395dfe25a3b9a09b5b9e788f3",
    "url": "/img/icon_facebook.df632b43.svg"
  },
  {
    "revision": "8471e557445f610955a02784f50d2142",
    "url": "/img/follow/follow-phelomi04.jpg"
  },
  {
    "revision": "446e83af28270c15579738ce7083cd29",
    "url": "/img/follow/follow-phelomi02.jpg"
  },
  {
    "revision": "8040542519ed46f3f3dbc5608c3e012f",
    "url": "/img/img_sm/PengHoFunSummer.jpg"
  },
  {
    "revision": "db3b10a9add92d1a21bb279e92f240bf",
    "url": "/img/img_sm/SpSales.jpg"
  },
  {
    "revision": "ae4dbede9d81a20c842b30332ab4e5b6",
    "url": "/img/materialdesignicons-webfont.ae4dbede.svg"
  },
  {
    "revision": "ae21c1cfa3f56d9b532fdabf1841964f",
    "url": "/img/qrcode-wechat.ae21c1cf.jpg"
  },
  {
    "revision": "8813054c652e01fc7a0640eba645656e",
    "url": "/img/icon-address.8813054c.svg"
  },
  {
    "revision": "61db5d0f44b4f9acfbe7e90cbf8e6c38",
    "url": "/img/cloud03.61db5d0f.png"
  },
  {
    "revision": "22c89b842f53c45520536192f7e2cd53",
    "url": "/img/icon_ship.22c89b84.svg"
  },
  {
    "revision": "90bf12eec51d4f67af807b07f464dd9b",
    "url": "/img/footer_ship.90bf12ee.svg"
  },
  {
    "revision": "289cca12abb662a0ece838906944c4a8",
    "url": "/img/button_bg_order.289cca12.png"
  },
  {
    "revision": "5fec65adc015c0f0559b20b85921ce68",
    "url": "/img/cloud01.5fec65ad.png"
  },
  {
    "revision": "e95712e2f1bef031055432ced9c7a115",
    "url": "/img/map_airplane.e95712e2.png"
  },
  {
    "revision": "a387d9f5de3fc8c0090c665de499e79b",
    "url": "/img/icon_phone.a387d9f5.svg"
  },
  {
    "revision": "2372bd976a5298f76a3a0dd24a4abdf7",
    "url": "/img/bg_order.2372bd97.png"
  },
  {
    "revision": "8d94fb10d5d21d139de3105904bfc0f5",
    "url": "/img/icon_line.8d94fb10.svg"
  },
  {
    "revision": "3c6f5631cf1b7e5593ff542f3e0d72c5",
    "url": "/img/footer_map.3c6f5631.svg"
  },
  {
    "revision": "20afa8e4945a2210baee2c997c2a87b3",
    "url": "/img/icon_position.20afa8e4.svg"
  },
  {
    "revision": "5b261d0ef7d54c0898007b68beee6e5e",
    "url": "/img/button_header_active.5b261d0e.png"
  },
  {
    "revision": "f547d239535356c5f039f4e4781ff9f3",
    "url": "/img/rooms/atpo/atpo03.jpg"
  },
  {
    "revision": "60d3647102d094a6b96b5f0572f28400",
    "url": "/img/rooms/atio/atio01.jpg"
  },
  {
    "revision": "5500470ed59c4eabb4f57df259abceb7",
    "url": "/img/news/new-ship.jpg"
  },
  {
    "revision": "42a9d4cb52d8f370128ba6fa6f8148b7",
    "url": "/img/rooms/atcs/atcs04.jpg"
  },
  {
    "revision": "a3b434fc18aee0cdbad29599f50250e7",
    "url": "/img/rooms/atio/atio04.jpg"
  },
  {
    "revision": "c66c5918a39ccb2a45012299f80221e4",
    "url": "/img/rooms/atcs/atcs02.jpg"
  },
  {
    "revision": "0727ac42fe598cbd68aec3ca3c6eb7ca",
    "url": "/img/rooms/atio/atio02.jpg"
  },
  {
    "revision": "6716750c2edcd70094dbb9e60a3f79ab",
    "url": "/img/rooms/atis/atis02.jpg"
  },
  {
    "revision": "25516972387e3d6a542c23508f98b032",
    "url": "/img/rooms/atis/atis04.jpg"
  },
  {
    "revision": "25d1f405c1d9aef9ea03bb11e2a8f7db",
    "url": "/img/rooms/atcs/atcs01.jpg"
  },
  {
    "revision": "74265def5034c36788060abf65a3e6df",
    "url": "/img/rooms/ata/ata02.jpg"
  },
  {
    "revision": "5be31801636ee96e80a6970a7105fd1c",
    "url": "/img/rooms/afao/afao03.jpg"
  },
  {
    "revision": "37fbc59631f7da69994ded6b3cc6c9df",
    "url": "/img/rooms/ata/ata01.jpg"
  },
  {
    "revision": "0a0c7742ce29a9896b97c55f5df78152",
    "url": "/img/rooms/atpo/atpo01.jpg"
  },
  {
    "revision": "1fc4a84d5d711061a0c08bb1d0b6827b",
    "url": "/img/rooms/atpo/atpo02.jpg"
  },
  {
    "revision": "1f18c806a4c049013c67b22f129f1c1f",
    "url": "/img/rooms/atio/atio03.jpg"
  },
  {
    "revision": "ac1fb6b68cd938024f4f3d492ef59a71",
    "url": "/img/rooms/ata/ata03.jpg"
  },
  {
    "revision": "884ee8ccb033b1d02dc3c09f460d9112",
    "url": "/img/rooms/afao/afao01.jpg"
  },
  {
    "revision": "3c1701fc8e72f13cd6568c4545d8e1fd",
    "url": "/img/rooms/atis/atis03.jpg"
  },
  {
    "revision": "61e46be4ef59fd10f097a1e8ed2f5907",
    "url": "/img/rooms/atis/atis01.jpg"
  },
  {
    "revision": "ac8d09f47a75d82282374a0fd8e71724",
    "url": "/img/rooms/afao/afao02.jpg"
  },
  {
    "revision": "49b8fb256f9e46253437b421169481e7",
    "url": "/img/rooms/atcs/atcs03.jpg"
  },
  {
    "revision": "e6abbc09d5a99ebf8f555afdcbf42c99",
    "url": "/img/rooms/afao/afao04.jpg"
  },
  {
    "revision": "e5a0868f07e249ed4a3cf0d9c826dca6",
    "url": "/img/news/music2019.jpg"
  },
  {
    "revision": "eeaa9f3dc8212e210b33f6b203ce8426",
    "url": "/img/map_ship.eeaa9f3d.png"
  },
  {
    "revision": "17bdd48f15c68d92d0a4258e2c2c343a",
    "url": "/img/cloud_left.17bdd48f.svg"
  },
  {
    "revision": "5930ff0ec8df4e7eeb5ce1e2c684997d",
    "url": "/img/footer_foreground.5930ff0e.svg"
  },
  {
    "revision": "602cf360012ae2e890c00c2b3fd50463",
    "url": "/img/bg_maintenance.602cf360.svg"
  },
  {
    "revision": "dcc98672a0114a063ff0871c1406f308",
    "url": "/img/icon_white_line.dcc98672.svg"
  },
  {
    "revision": "76a479d9b077f5edca1a8e88a62bfb0f",
    "url": "/img/footer_background.76a479d9.svg"
  },
  {
    "revision": "28822f791248b54df45b5f1666618565",
    "url": "/img/map_position.28822f79.png"
  },
  {
    "revision": "2b3fcde58af5d2b70a2cae73b87f2925",
    "url": "/img/logo_vertical.2b3fcde5.svg"
  },
  {
    "revision": "256a75a236de69ba8abcdef28b1d8221",
    "url": "/img/icon_position.256a75a2.svg"
  },
  {
    "revision": "e3e1c5140f31a46dd2e1e6098ba78d72",
    "url": "/img/cloud02.e3e1c514.png"
  },
  {
    "revision": "6243d3833e5ae5a188b026ebe50b6e1d",
    "url": "/img/icon_email.6243d383.svg"
  },
  {
    "revision": "5cfc5ed1f03056368fe5c39af11eed36",
    "url": "/img/rooms/afas/afas03.jpg"
  },
  {
    "revision": "5551333d64dfb2f74dc36c88dd590cc1",
    "url": "/img/rooms/afas/afas04.jpg"
  },
  {
    "revision": "cc9a7323e3599f53ff59f5200cae47c6",
    "url": "/img/img_sm/placeholder.jpg"
  },
  {
    "revision": "0f8d51f26902e7a0e081f4526564ed8f",
    "url": "/img/map_arrow.0f8d51f2.svg"
  },
  {
    "revision": "7fd7f09ce3e94213071ac4bad5bcded9",
    "url": "/img/button_order_active.7fd7f09c.svg"
  },
  {
    "revision": "1d2cdeb6e8eade0838f75dc943295043",
    "url": "/img/icon_airplane_active.1d2cdeb6.svg"
  },
  {
    "revision": "c4ec317578d063a79397918350aeed4d",
    "url": "/img/follow/ad_sm002.jpg"
  },
  {
    "revision": "5d45f0630b445173eeea45f623d5ef5c",
    "url": "/img/follow/follow-phelomi01.jpg"
  },
  {
    "revision": "c497edc5fdbc8c931c62a41d2b52a2c3",
    "url": "/img/icon_ship_active.c497edc5.svg"
  },
  {
    "revision": "411860f37055806ff3d826df07bf8581",
    "url": "/img/icon_position_active.411860f3.svg"
  },
  {
    "revision": "bcd9739c134a8131f8854afa3cf73dff",
    "url": "/img/button_rooms_active_arrow.bcd9739c.svg"
  },
  {
    "revision": "bea3d8f400c48cb70a9c6fde2f8c82bc",
    "url": "/img/button_rooms_active.bea3d8f4.svg"
  },
  {
    "revision": "68be39881ef35f9ca8493c2d3d82bb21",
    "url": "/img/icon_star.68be3988.svg"
  },
  {
    "revision": "fad5e078adcdc319bca6c456eef8692a",
    "url": "/img/bg_placeholder.fad5e078.jpg"
  },
  {
    "revision": "7c12bc30c4314552764c6a6e59251b35",
    "url": "/img/logo_horizon.7c12bc30.svg"
  },
  {
    "revision": "d8d0e9918afeaef529ad2998f7d84e6c",
    "url": "/img/rooms/afas/afas01.jpg"
  },
  {
    "revision": "283afda1bcf5dabab2602d4d98744bd9",
    "url": "/img/rooms/afas/afas02.jpg"
  },
  {
    "revision": "3a3e5aa23ba26299d0bf35d46a6efb4c",
    "url": "/img/follow/ad_sm003.jpg"
  },
  {
    "revision": "8ead59b72f38856cc06361b002d722be",
    "url": "/img/follow/ad_sm001.jpg"
  },
  {
    "revision": "dfb5f1bea35e21f54264389c77728894",
    "url": "/img/img_sm/news003.jpg"
  },
  {
    "revision": "2867fde354b424e8bf9f95b381be48f5",
    "url": "/img/follow/follow-phelomi03.jpg"
  },
  {
    "revision": "d059562047873e0e93781223050974e4",
    "url": "/img/img_sm/news002.jpg"
  },
  {
    "revision": "d2a9ee38ab5f3a0cd36da2bac9f35fbf",
    "url": "/img/follow/follow-phelomi05.jpg"
  },
  {
    "revision": "d3b47375afd904983d9be8d6e239a949",
    "url": "/fonts/Roboto-Thin.d3b47375.woff"
  },
  {
    "revision": "010aa1ffe57d99a5150d",
    "url": "/css/chunk-772256ae.75cdff95.css"
  },
  {
    "revision": "f659e93e084d949fd30035cff184d6da",
    "url": "/img/bg_footer.f659e93e.png"
  },
  {
    "revision": "97c6d1a4793d8a5d80222415a09cc29b",
    "url": "/img/banner/banner005.jpg"
  },
  {
    "revision": "3b20876c092ade1af3510ac3aa3f0035",
    "url": "/img/bg_image/bg_haveFun.jpg"
  },
  {
    "revision": "6fbc05294fe93258798b",
    "url": "/css/chunk-7722bfab.29344134.css"
  },
  {
    "revision": "9fc70d798bcb92abcfd4",
    "url": "/css/chunk-77271350.21d807f4.css"
  },
  {
    "revision": "135de449b014bfbf1455b98e52bc85b6",
    "url": "/img/banner/banner004.jpg"
  },
  {
    "revision": "4bbbf7cf184479a6b392",
    "url": "/css/chunk-772efa8c.2df2f851.css"
  },
  {
    "revision": "8a7186d9a23f025b3f2f",
    "url": "/css/chunk-vendors.20756bf1.css"
  },
  {
    "revision": "459118748df2a5fcd7f684546cc8591b",
    "url": "/fonts/materialdesignicons-webfont.45911874.woff2"
  },
  {
    "revision": "4981aad6ae4562d777c84c0246e243a6",
    "url": "/img/banner/banner001.jpg"
  },
  {
    "revision": "33bbacc3a3cb302fd66b43e498a18112",
    "url": "/img/banner/banner002.jpg"
  },
  {
    "revision": "4b882ad484d11b49f4a69212ad8e8901",
    "url": "/fonts/materialdesignicons-webfont.4b882ad4.woff"
  },
  {
    "revision": "23c86ad577fab4104789b1a76cc0e833",
    "url": "/img/bg_image/bg_order.png"
  },
  {
    "revision": "d15c1216957060fac577af6151fb8cfe",
    "url": "/fonts/materialdesignicons-webfont.d15c1216.ttf"
  },
  {
    "revision": "cc2fadc3928f2f223418887111947b40",
    "url": "/fonts/Roboto-BlackItalic.cc2fadc3.woff"
  },
  {
    "revision": "abb4e7492eaa88c31ff103064f2b2cba",
    "url": "/fonts/materialdesignicons-webfont.abb4e749.eot"
  },
  {
    "revision": "4fe0f73cc919ba2b7a3c36e4540d725c",
    "url": "/fonts/Roboto-BoldItalic.4fe0f73c.woff"
  },
  {
    "revision": "83e114c316fcc3f23f524ec3e1c65984",
    "url": "/fonts/Roboto-MediumItalic.83e114c3.woff"
  },
  {
    "revision": "ad538a69b0e8615ed0419c4529344ffc",
    "url": "/fonts/Roboto-Thin.ad538a69.woff2"
  },
  {
    "revision": "73f0a88bbca1bec19fb1303c689d04c6",
    "url": "/fonts/Roboto-Regular.73f0a88b.woff2"
  },
  {
    "revision": "d26871e8149b5759f814fd3c7a4f784b",
    "url": "/fonts/Roboto-Light.d26871e8.woff2"
  },
  {
    "revision": "13efe6cbc10b97144a28310ebdeda594",
    "url": "/fonts/Roboto-LightItalic.13efe6cb.woff"
  },
  {
    "revision": "f5902d5ef961717ed263902fc429e6ae",
    "url": "/fonts/Roboto-RegularItalic.f5902d5e.woff"
  },
  {
    "revision": "8a96edbbcd9a6991d79371aed0b0288e",
    "url": "/fonts/Roboto-ThinItalic.8a96edbb.woff"
  },
  {
    "revision": "90d1676003d9c28c04994c18bfd8b558",
    "url": "/fonts/Roboto-Medium.90d16760.woff2"
  },
  {
    "revision": "50d75e48e0a3ddab1dd15d6bfb9d3700",
    "url": "/fonts/Roboto-Bold.50d75e48.woff"
  },
  {
    "revision": "b52fac2bb93c5858f3f2675e4b52e1de",
    "url": "/fonts/Roboto-Bold.b52fac2b.woff2"
  },
  {
    "revision": "f86705b7883c8ad4ecfdca3d03dda440",
    "url": "/img/banner/banner003.jpg"
  },
  {
    "revision": "59eb3601394dd87f30f82433fb39dd94",
    "url": "/fonts/Roboto-Black.59eb3601.woff2"
  },
  {
    "revision": "e8eaae902c3a4dacb9a5062667e10576",
    "url": "/fonts/Roboto-LightItalic.e8eaae90.woff2"
  },
  {
    "revision": "313a65630d341645c13e4f2a0364381d",
    "url": "/fonts/Roboto-Black.313a6563.woff"
  },
  {
    "revision": "1d6594826615607f6dc860bb49258acb",
    "url": "/fonts/Roboto-Medium.1d659482.woff"
  },
  {
    "revision": "35b07eb2f8711ae08d1f58c043880930",
    "url": "/fonts/Roboto-Regular.35b07eb2.woff"
  },
  {
    "revision": "c73eb1ceba3321a80a0aff13ad373cb4",
    "url": "/fonts/Roboto-Light.c73eb1ce.woff"
  },
  {
    "revision": "5b4a33e176ff736a74f0ca2dd9e6b396",
    "url": "/fonts/Roboto-ThinItalic.5b4a33e1.woff2"
  },
  {
    "revision": "4357beb823a5f8d65c260f045d9e019a",
    "url": "/fonts/Roboto-RegularItalic.4357beb8.woff2"
  },
  {
    "revision": "13ec0eb5bdb821ff4930237d7c9f943f",
    "url": "/fonts/Roboto-MediumItalic.13ec0eb5.woff2"
  },
  {
    "revision": "f75569f8a5fab0893fa712d8c0d9c3fe",
    "url": "/fonts/Roboto-BlackItalic.f75569f8.woff2"
  },
  {
    "revision": "94008e69aaf05da75c0bbf8f8bb0db41",
    "url": "/fonts/Roboto-BoldItalic.94008e69.woff2"
  },
  {
    "revision": "4320d321b75f98c0a3a2",
    "url": "/css/chunk-74697fd9.86e39baa.css"
  },
  {
    "revision": "58b1cb5de4346046cdab",
    "url": "/css/chunk-7477fe0a.76965173.css"
  },
  {
    "revision": "b36b9836f75281c22331",
    "url": "/css/chunk-7482abbb.c8d9ae0f.css"
  },
  {
    "revision": "fa5305ad9dc2a8b0e42e",
    "url": "/css/chunk-771afaf2.c114e4f6.css"
  },
  {
    "revision": "2eb26b7547b91e485987",
    "url": "/css/chunk-7718b8f7.6679f161.css"
  },
  {
    "revision": "432d932cfef90e7686f2",
    "url": "/css/chunk-7484083d.f65e4a87.css"
  },
  {
    "revision": "a0210b799d69b57e1f16",
    "url": "/css/chunk-770e1ae5.69d77d8f.css"
  },
  {
    "revision": "1001d9a612a973a95629",
    "url": "/css/chunk-76fe9cf4.01201d47.css"
  },
  {
    "revision": "8232cd625bab1f5768ab",
    "url": "/css/chunk-74847767.1bb9eba2.css"
  },
  {
    "revision": "85b2d9b109b99f84ea0e",
    "url": "/css/chunk-748a351e.0a9f5724.css"
  },
  {
    "revision": "e570e0a516c3f05c8d31",
    "url": "/css/chunk-74b10368.4d5b9433.css"
  },
  {
    "revision": "29fdd09f8d116d41c776",
    "url": "/css/chunk-74b6f911.15a377f8.css"
  },
  {
    "revision": "b9e35cc6b12dcc654a37",
    "url": "/css/chunk-74bc2e8d.d56b81c4.css"
  },
  {
    "revision": "54adc26ac13982921fb1",
    "url": "/css/chunk-74bcdefc.8b75978f.css"
  },
  {
    "revision": "fd02296e2d46eccf2344",
    "url": "/css/chunk-76f25df5.43f8b560.css"
  },
  {
    "revision": "bca0107a988e5d45778d",
    "url": "/css/chunk-747d763f.b334a195.css"
  },
  {
    "revision": "74e54790d32739a90ff7",
    "url": "/css/chunk-74d2b031.7c7a9349.css"
  },
  {
    "revision": "b7f6fa41a5c23d3d9c32",
    "url": "/css/chunk-76f13012.0e433876.css"
  },
  {
    "revision": "78f046e91b20c8313198764a797ce335",
    "url": "/app.html"
  },
  {
    "revision": "3e3e229750919cd6c331",
    "url": "/css/chunk-746799a8.c1291e20.css"
  },
  {
    "revision": "13e1aa9f8cb59bd85a05",
    "url": "/css/chunk-7476dfa7.705436ed.css"
  },
  {
    "revision": "9f7635024ca49c675ad2",
    "url": "/css/chunk-7475f6ab.c472db02.css"
  },
  {
    "revision": "d5bf659b2d13f70f0a2d",
    "url": "/css/chunk-74704285.15e03f7b.css"
  },
  {
    "revision": "49166fedb4131f75b215",
    "url": "/css/chunk-74693142.590e2f8c.css"
  },
  {
    "revision": "9c564d8e93f7d6cfe5e1",
    "url": "/css/chunk-746f9064.cebd1ae4.css"
  },
  {
    "revision": "c19c266c02b72c75f31d",
    "url": "/css/chunk-74544e1f.d6b89405.css"
  },
  {
    "revision": "1c6f2a2d22ae19761275",
    "url": "/css/chunk-23a2ccf2.c1ba0cd9.css"
  },
  {
    "revision": "3f7ad64345bd9b6644c4",
    "url": "/css/chunk-22d5a82a.03198c6f.css"
  },
  {
    "revision": "14ab431280c95d8689d6",
    "url": "/css/chunk-187f2124.14f5a390.css"
  },
  {
    "revision": "346769a35e9f19e119f6",
    "url": "/css/app.3ee41afb.css"
  },
  {
    "revision": "682cafea2ac9d4b0d13863977c9454a7",
    "url": "/CustomEase.min.js"
  }
];